@extends('layouts.app')
@section('content')
    <h1>Welcome to laravel</h1>
    <p>This is a laravel application.</p>
@endsection