@extends('layouts.app')

@section('content')
    <h1>Showing databases content.</h1>
    @if(count($data) > 0)
        @foreach ($data as $item)
            <div class="well">
                <h3>{{$item->title}}</h3>
                <h5>{{$item->body}}</h5>
            </div>
        @endforeach
    @else 
        <h2>No data found.</h2>
    @endif
@endsection