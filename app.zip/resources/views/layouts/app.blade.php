<!doctype html>
<html lang={{ config('app.locate') }}>
    <head>
        <meta charset="utf-8">
        <title>{{config('app.name','LSAPP')}}</title>
    </head>
    <body>
        @yield('content')
    </body>
</html>